import datetime
import smtplib
import subprocess
import sys
import webbrowser


# Function to install required libraries
def install_libraries():
    try:
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', 'pyttsx3', 'wikipedia'])
        print("Libraries installed successfully!")
    except subprocess.CalledProcessError:
        print("Failed to install libraries. Please install them manually using 'pip install pyttsx3 wikipedia'.")


# Check if the required libraries are installed
try:
    import pyttsx3
    import wikipedia
except ImportError:
    print("Required libraries not found. Installing...")
    install_libraries()
    # After installation, attempt to import the libraries again
    try:
        import pyttsx3
        import wikipedia
    except ImportError:
        print("Failed to install required libraries. Exiting.")
        sys.exit(1)

# Initialize the text-to-speech engine
engine = pyttsx3.init()


def execute_command(query):
    if "wikipedia" in query:
        search_query = query.replace("wikipedia", "")
        try:
            speak(f"According to Wikipedia, {wikipedia.summary(search_query, sentences=2)}")
        except wikipedia.exceptions.DisambiguationError:
            speak("There are multiple possible matches. Please be more specific.")
        except wikipedia.exceptions.PageError:
            speak("Sorry, I could not find any information on that topic.")
    elif "search" in query:
        search_query = query.replace("search", "")
        webbrowser.open_new_tab(f"https://www.google.com/search?q={search_query}")
    elif "time" in query:
        current_time = datetime.datetime.now().strftime("%I:%M %p")
        speak(f"The current time is {current_time}.")
    elif "date" in query:
        current_date = datetime.datetime.now().strftime("%B %d, %Y")
        speak(f"Today's date is {current_date}.")
    elif "send email" in query:
        send_email()
    else:
        speak("Sorry, I don't understand that command.")


def speak(text):
    engine.say(text)
    engine.runAndWait()


def send_email():
    speak("Please enter the details to send the email.")
    sender_email = input("Enter your email address: ")
    sender_password = input("Enter your email password: ")
    receiver_email = input("Enter the recipient's email address: ")
    subject = input("Enter the email subject: ")
    body = input("Enter the email body: ")

    try:
        server = smtplib.SMTP('smtp.gmail.com', 587)
        server.starttls()
        server.login(sender_email, sender_password)
        email_message = f"Subject: {subject}\n\n{body}"
        server.sendmail(sender_email, receiver_email, email_message)
        server.quit()
        speak("Email sent successfully!")
    except Exception as e:
        print(e)
        speak("Sorry, I could not send the email. Please try again.")


def main():
    speak("Hello! I'm Pestingo How can I assist you today?")
    while True:
        query = input("You: ").lower()
        if query == "stop":
            speak("Goodbye!")
            break
        else:
            execute_command(query)


if __name__ == "__main__":
    main()
